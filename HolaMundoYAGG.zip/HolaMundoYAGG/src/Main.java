import java.time.LocalTime;

public class Main {
    public static void main(String[] args) {
        System.out.println("Yael Abiezer García Guerra - 2050107");
        System.out.println("\n" + LocalTime.now());
    }
}