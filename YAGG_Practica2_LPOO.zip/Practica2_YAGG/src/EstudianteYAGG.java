public class EstudianteYAGG {
    private String nombre;
    private final String matricula;
    private int edad;
    private String carrera;
    private int semestreActual;

    public EstudianteYAGG(String nombre, String matricula, int edad, String carrera, int semestreActual){
        this.nombre = nombre;
        this.matricula = matricula;
        this.edad = edad;
        this.carrera = carrera;
        this.semestreActual = semestreActual;
    }

    public EstudianteYAGG(String matricula){
        this("NoName", matricula, 0, "NoCareer", 0);
    }

    public EstudianteYAGG(String nombre, String matricula, int edad, int  semestreActual){
        this.nombre = nombre;
        this.matricula = matricula;
        this.edad = edad;
        this.semestreActual = semestreActual;
        this.carrera = "Unknown";
    }

    public String getInfo(){
        return "Nombre: " + this.nombre +
                "\nMatricula: " + this.matricula +
                "\nEdad: " + this.edad +
                "\nCarrera: " + this.carrera +
                "\nSemestre Actual: " + this.semestreActual;
    }

    public void changeName(String newName){
        this.nombre = newName;
    }

    public void changeCareer(String newCareer){
        this.carrera = newCareer;
    }

    public void changeSemester(int newSemester){
        this.semestreActual = newSemester;
    }

    public void changeAge(int newAge){
        this.edad = newAge;
    }

    public String getMatricula(){
        return this.matricula;
    }
}