import java.sql.SQLOutput;

public class MainYAGG {
    public static void main(String[] args) {
        System.out.println("========================= UNIVERSIDAD =========================");

        EstudianteYAGG student1 = new EstudianteYAGG("Yael Garcia", "2050107", 19, "LCC", 5);
        EstudianteYAGG student2 = new EstudianteYAGG("Liliana Ramos", "2056778", 21, "LCC", 5);
        EstudianteYAGG student3 = new EstudianteYAGG("Alma Arangua", "2010364", 20, "LMAD", 4);
        EstudianteYAGG student4 = new EstudianteYAGG("Hector Hermosillo", "2121179", 23, 7);
        EstudianteYAGG student5 = new EstudianteYAGG("2035527");

        student4.changeCareer("LA");

        student5.changeName("Mateus Astato");
        student5.changeAge(27);
        student5.changeCareer("LSTI");
        student5.changeSemester(9);

        Universidad0107 uni = new Universidad0107();
        uni.addStudent(student1);
        uni.addStudent(student2);
        uni.addStudent(student3);
        uni.addStudent(student4);
        uni.addStudent(student5);

        System.out.println("\n========== BUSQUEDA DE ALUMNOS ==========");
        System.out.println(uni.searchStudent("2121179"));
        System.out.println("\n" + uni.searchStudent("0011223"));

        System.out.println("\n========== ESTUDIANTES DE LA UNIVERSIDAD ==========");
        uni.showStudents();
    }
}