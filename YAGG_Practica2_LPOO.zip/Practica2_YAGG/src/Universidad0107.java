public class Universidad0107 {
    private EstudianteYAGG[] university;
    private int numStudents=0;

    public Universidad0107(){
        university = new EstudianteYAGG[10];
    }

    public void addStudent(EstudianteYAGG student){
        if(numStudents == university.length){
            System.out.println("El maximo de alumnos ha sido alcanzado...");
        }
        else{
            university[numStudents] = student;
            numStudents++;
        }
    }

    public String searchStudent(String matricula){
        for(int i=0 ; i<numStudents ; i++){
            if(university[i].getMatricula().equals(matricula)){
                return "El alumno de matricula " + matricula + " es:\n" + university[i].getInfo();
            }
        }
        return "No se ha encontrado un alumno de matricula " + matricula + "...";
    }

    public void showStudents(){
        for(int i=0 ; i<numStudents ; i++){
            System.out.println("\nAlumno " + (i+1) + ":");
            System.out.println(university[i].getInfo());
        }
    }
}
