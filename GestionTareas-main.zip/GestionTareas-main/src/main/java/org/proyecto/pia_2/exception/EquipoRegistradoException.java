package org.proyecto.pia_2.exception;

public class EquipoRegistradoException extends Exception {
    public EquipoRegistradoException(String message) {
        super(message);
    }
}
