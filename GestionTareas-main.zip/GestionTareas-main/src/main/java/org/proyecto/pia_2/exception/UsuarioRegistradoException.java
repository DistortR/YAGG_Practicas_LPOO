package org.proyecto.pia_2.exception;

public class UsuarioRegistradoException extends RuntimeException {
    public UsuarioRegistradoException(String message) {
        super(message);
    }
}
