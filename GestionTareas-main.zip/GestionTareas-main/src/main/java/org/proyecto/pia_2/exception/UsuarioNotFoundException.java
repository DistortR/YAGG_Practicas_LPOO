package org.proyecto.pia_2.exception;

public class UsuarioNotFoundException extends Exception {
    public UsuarioNotFoundException(String message) {
        super(message);
    }
}
